#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <windows.h>
int TongNV = 10;
int ChiSoNv = 0;
struct thongTin_nv {
	char hoTen[30];
	char namSinh[10];
	char soDienThoai[11];
	char Mail[30];
	char diaChi[30];
}thongTin[20];

struct DangNhap{
	char taiKhoang[10];
	char matKhau[10];
	char maNhanVien[5];	
	thongTin_nv nv[20];
};

int MangHinhlogin();
void LuaChon(int chon, DangNhap DN[]);
void CLearScreen();
void func_DangNhap(char output[20], DangNhap DN[]);
void func_DangKY(char input[20],DangNhap DN[]);
void Display();
int KiemTra_TK(char Tk[], char tapTin[] );
void LayTaiKhoang_NV(DangNhap DN[], char TapTin[20]); 
/*void XuatTaiKhoang_NV(DangNhap DN[])
{	
	for(int i = 0; i <= TongNV; i++)
	{
		printf("\n%s", DN[i].taiKhoang);
		printf("\n%s", DN[i].matKhau);
		printf("\n%s", DN[i].maNhanVien);
	}
}*/
void DangKyThongTin(DangNhap DN[], int maNV);


int main ()
{	
	struct	DangNhap DN[20];
	int chon;
	
	do 
	{
		LayTaiKhoang_NV(DN, "TaiKhoangNhanVien.txt");
		chon = MangHinhlogin();
		LuaChon(chon, DN);
		printf("\n%30s============================================", " ");
		printf("\n%30sBan muon tiep tuc : 1. Co\t\t2.Khong ", " ");
		printf("\n%30s============================================", " ");
		printf("\n%30sBan chon :", " ");
		scanf("%d", &chon);
	}while(chon==1);

	
}
void DauCach()
{
	for(int i = 0; i < 90; i++)
		printf(" ");
}

void NgoiSao()
{
	system("color 3");
	
	int i, j, k = 9;
	for(j = 1; j <= k; j++)
	{
		printf("\t\t\t\t\t\t");
		for( i = 1; i <= k - j; i++)		
			printf(" ");
			
		for(i = 1; i <= j; i++)
			printf("* ");
	
	printf("\n");
	}
	for(j = 2; j <= k; j++)
		{		
			printf("\t\t\t\t\t\t");
			for(i = 1; i < j; i++)
				printf(" ");
			for(i = k; i >= j; i--)
				printf("* ");
			
			printf("\n");
		}
		system("color 0");

}

int  MangHinhlogin()
{	
	static int z = 1;
	int p = 25;
	if(z > 1)
	 p = 10;
	z++;
	printf("\n\n\n\n\n\n\n\n%50s", " ");
	printf("Loading...\n\t\t\t\t\t ");
  for(int r=1; r<=2; r++)
    {
        for(int q=0; q<=100000000; q++); //to display the character slowly
        printf("%c",177);
   		
    }
    CLearScreen();
    printf("\t\t\t\t\t\t    %s\t\t\t\t\t\t\n", __TIME__);
    printf("\t\t\t\t\t\t  %s\t\t\t\t\t\t\n", __DATE__);
   	printf("===============");
   	DauCach();
   	
   	printf("===============");
   	printf("= 1.Dang nhap =");
   	
   	DauCach();
   	
   	printf("=  2.Dang ky  =");
	printf("===============");
	
   	DauCach();
   	
   	printf("===============\n");	
   	NgoiSao();
   	
  	printf("===============");
   	DauCach();
   	
   	printf("===============");
   	printf("=  3.Check Ca =");
   	DauCach();
   	
   	printf("=   4. Thoat  =");
	printf("===============");
   	DauCach();
   	
   	printf("===============");	
   	
	int chon;
	printf("\t\t\t\t\t\t\t===============\n");
	printf("\t\t\t\t\t\t# Ban chon : "); scanf("%d", &chon);
	return chon;
}

void CLearScreen()
{
	
	for(int i = 0; i < 10; i++)
		printf("\n\n\n\n\n");
}

void LuaChon(int chon, DangNhap DN[])
{
		switch (chon)
		{
			case 1: 
			{	// DangNhap
				func_DangNhap("TaiKhoangNhanVien.txt", DN);
				break;
			}
			case 2:
			{
				//	DangKy();
				func_DangKY("TaiKhoangNhanVien.txt", DN);
				break;
			}
			case 3: 
			{
			//	Check_ca_truc();	
				break;
			}
			default : exit(0);
		}
		
}

void LayTaiKhoang_NV(DangNhap DN[], char TapTin[20])
{
	FILE *f;
	f = fopen(TapTin, "r");
	int i = 0;
	rewind(f);
	while(!feof(f))
	{
		fscanf(f, "%s", DN[i].taiKhoang); 
		fscanf(f, "%s", DN[i].matKhau); 
		fscanf(f, "%s", DN[i].maNhanVien); 
	i++;
	}	
	fclose(f);
}
int checkMk(char P[], DangNhap DN[])
{	int temp = 0;
	int i = 0;
	int len = strlen(P);
	int M = 0;
	while(i < TongNV)
	{
		temp = 0;
		while(temp < len)
			{ 
				if(DN[i].matKhau[temp] == P[temp])
					 M++;
			temp++;
			}	
		if(M == len)
		{
		ChiSoNv = i;
		return 1;// Trung mat khau
		}
		i++;
	}	
		return 0; // Khong dung
}
void func_DangNhap(char output[20], DangNhap DN[])
{
	CLearScreen();
	fflush(stdin);
	printf("\n%50sDANG NHAP"," ");
	FILE *f;
	f = fopen(output, "r");
	char TK[20];
	char Mk[20];
L3:	printf("\n\n%30sNhap tai khoang : ", " ");
	gets(TK);
	printf("\n\n%30sNhap mat khau   : ", " ");
	gets(Mk);

	
	if(KiemTra_TK(TK, "TaiKhoangNhanVien.txt") == 0)// kiem tra tai khoang
		if(checkMk(Mk, DN) == 1) // dung roi 
			return ; //Chuyen dem ham dang ky thong tin
		else // sai tai khoang hoac mat khau
			{
				printf("\n%30sTai khoang hoac mat khau khong dung!!!"," ");
				printf("\n%30sNhap lai :"," ");
				goto L3;
			}
	else // khong tim thay tai khoang
		{
			printf("\n%30sKhong tim thay tai khoang", " ");
		}
	
	
	fclose(f);
	
}

int KiemTra_TK(char Tk[], char tapTin[] )
{
	FILE *f;
	f = fopen(tapTin, "r");
	
	char kytu[20];
	int len = strlen(Tk); 
	int Dem = 0;
	int i = 0;
	char x[2];
	int len1;
	rewind(f);
	if(feof(f)) //FILE khong co du lieu
		return 1;
	while(!feof(f))//chay cuoi file
	{
		fscanf(f, "%s", kytu);
		i = 0;
		Dem = 0;
		len1 = strlen(kytu);

		if(len1 == len){
			while( i < len1)
				{	
					if(kytu[i] == Tk[i])				
						Dem++;					
					i++;
				}
			if(Dem == len)
				return 0;
		}
	}
	fclose(f);
	return 1;
}

int KiemTra_Mk(char Mk[])
{
	int i = 0;
	while(Mk[i] != NULL)
	{
		if(!(Mk[i] >= 'A' && Mk[i] <= 'Z' || Mk[i] >= 'a' && Mk[i] <= 'z' || Mk[i] >= '0' && Mk[i] <= '9' ))
		{
			printf("\n%30sMat khau khong co ki tu dat biet"," ");
			return 1;
		}
		i++;
	}
	return 0;
}

void GoiY(char TK[])
{
	int r;
    srand((int)time(0));
    for(int i = 0; i < 3; ++i){
        r = rand();
        printf("%s%d\t", TK, r);
    }   
}
int SoSanh(char mk1[], char mk2[])
{
	int i = 0;
	int temp = 0;
	int len1 = strlen(mk1);
	int len2 = strlen(mk2);
	if(len1 == len2){
		while(i < len1)
		{
			if(mk1[i] != mk2[i])
				{
					temp = 0;
					goto m;	
				}
			i++;
		}
		temp = 1;
	}	
	else
		temp = 0;	
m:	if(temp == 0)
		printf("\n%30sMat khau xac nhan sai !!!", " ");
	return temp;
}

void func_DangKY(char input[20],DangNhap DN[])
{
	CLearScreen();
	fflush(stdin);
	static int maNV = 1;
	printf("\n%50s==========="," ");
	printf("\n%50s= DANG KY ="," ");
	printf("\n%50s==========="," ");
	
	FILE *f;
	FILE *ptr;
	ptr =  fopen("maNhanVien.txt", "r");
	char Tk[20];
	char Mk[20];
	f = fopen(input, "a+");
L1:	printf("\n\n%30s===============================================", " ");	
	printf("\n%30s= Nhap tai khoang : ", " ");
	gets(Tk);
	if(KiemTra_TK(Tk, "TaiKhoangNhanVien.txt" ) == 0)
	{
		printf("\n%30sTai khoang bi trung\n"," ");
		printf("\n%30sGoi y: ", " ");
		GoiY(Tk);
		goto L1;		
	}

L2:	printf("\n\n%30s=============================================== : ", " ");	
	printf("\n%30s Nhap mat khau   : ", " ");
	gets(Mk);
	if(KiemTra_Mk(Mk) == 1)
		goto L2;
	char Mktemp[20];
	printf("\n\n%30s=============================================== : ", " ");		
	printf("\n%30s Nhap mat khau xac nhan  : ", " ");	
	gets(Mktemp);
	//Kiem tra mat khau xac nhan
	if(SoSanh(Mk, Mktemp) == 0)
		goto L2;
		
	fprintf(f, "%s", Tk);
	fprintf(f, "\n%s", Mk);
	TongNV++;
	char ma[5];
	fscanf(ptr ,"%s", ma); //ma A0001
	fclose(ptr);

	ptr =  fopen("maNhanVien.txt", "w");
	//ma nhan vien 
	strcpy(DN[maNV].maNhanVien,ma);
	fprintf(f, "\n%s", DN[maNV].maNhanVien);
	
	char stt[2];
	int lengh = strlen(ma)-1;
	int x = ma[lengh] - 48;
		x++;

	itoa (x,stt,10);
	ma[lengh] = stt[0];

	fprintf(ptr, "%s", ma);
	fprintf(f, "\n");


	fclose(f);
	fclose(ptr);

	DangKyThongTin(DN, maNV);
}

int KiemTraHoTen(char p[])
{
	
	int i = 0;
	while(p[i] != NULL)
	{
		if(!(p[i] >= 'a' && p[i] <= 'z' || p[i] >= 'A' && p[i] <= 'Z' || p[i] == ' '))
			return 1;
		i++;
	}
	return 0;
}
/*	char hoTen[30];
	char namSinh[10];
	char soDienThoai[11];
	char Mail[30];
	char diaChi[30];*/
int KiemTraNamSinh(char p[])
{
	
	int i = 0;
	while(p[i] != NULL)
	{
		if(!(p[i] >= '0' && p[i] <= '9' || p[i] == '/'))
			return 1;
		i++;
	}
	return 0;
}

int KiemTraDT(char p[])
{
	
	int i = 0;
	while(p[i] != NULL)
	{
		if(!(p[i] >= '0' && p[i] <= '9' ))
			return 1;
		i++;
	}
	return 0;
}

int KiemTraMail(char p[])
{
	int i = 0;
	if(p[i] == '@')
		return 1;
	int Dem_A = 0;
	int Dem_Dau = 0;
	
	while(p[i] != NULL)
	{
		if(p[i] == '@')
			Dem_A++;
		if(p[i] == '.')
			Dem_Dau++;	
		i++;
	}
	if(Dem_A > 1)
		return 1;
	if(Dem_Dau < 1)
		return 1;
	return 0;	
}

void DangKyThongTin(DangNhap DN[], int maNV)
{
	FILE *p;
	p = fopen("ThongTinNhanVien.txt", "w");
	char Ten[30];
a1:	printf("\n%30sHo Ten :", " ");
	gets(Ten);
	if(KiemTraHoTen(Ten))
		goto a1;
	fprintf(p, "%s\n", Ten);
	strcpy(DN[ChiSoNv].nv[ChiSoNv].hoTen, Ten);
	
	char NamSinh[11];
a2:	printf("\n%30sNam sinh (dd/mm/yy):", " ");
	gets(NamSinh);
	if(KiemTraNamSinh(NamSinh))// kiem tra
		goto a2;
	fprintf(p, "%s\n", NamSinh);
	strcpy(DN[ChiSoNv].nv[ChiSoNv].namSinh, NamSinh);
	
	char sdt[11];
a3:	printf("\n%30sSo dien thoai :", " ");
	gets(sdt);
	if(KiemTraDT(sdt))// kiem tra
		goto a3;
	fprintf(p, "%s\n", sdt);
	strcpy(DN[ChiSoNv].nv[ChiSoNv].soDienThoai, sdt);
	
	char mail[30];
a4:	printf("\n%30sMail :", " ");
	gets(mail);
	if(KiemTraMail(mail))// kiem tra
		goto a4;
	fprintf(p, "%s\n", mail);
	strcpy(DN[ChiSoNv].nv[ChiSoNv].Mail, mail);	

	char DiaChi[40];
	printf("\n%30sDia chi :", " ");
	gets(DiaChi);
	fprintf(p, "%s\n", DiaChi);
	strcpy(DN[ChiSoNv].nv[ChiSoNv].diaChi, DiaChi);	
	//Ket thuc
	
	fclose(p);
}
